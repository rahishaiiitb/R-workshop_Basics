# Install the package. You can also do it through the Packages Tab
install.packages ("ggplot2") 

library(ggplot2)  # load the ggplot2 package
# define a canvas
ggplot(data = iris)

# map data to x and y coordinates 
ggplot(data = iris ) + 
  aes(x = Petal.Length, y = Petal.Width) 

# add data points
ggplot(data = iris) +
  aes(x = Petal.Length, y = Petal.Width) + 
  geom_point()

# change color & symbol type
ggplot(data = iris) +
  aes(x = Petal.Length, y = Petal.Width) + 
  geom_point( aes(color = Species, shape = Species) ) 


# add trend line
ggplot(data = iris) +
  aes(x = Petal.Length, y = Petal.Width) + 
  geom_point( aes(color = Species, shape = Species) ) +
  geom_smooth(method =lm)

ggplot(data = iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) + 
  geom_point() + 
  geom_smooth()

ggplot(data = iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) + 
  geom_point() + 
  geom_line()

#Changing Aesthetics

ggplot(data = iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) + 
  geom_smooth(aes(linetype = Species)) + 
  geom_point(aes(size = Species, shape = Species)) 

# add annotation text to a specified location by setting coordinates x = , y =
ggplot(data = iris) +
  aes(x = Petal.Length, y = Petal.Width) + 
  geom_point( aes(color = Species, shape = Species) ) +
  geom_smooth(method =lm) +
  annotate("text", x = 5, y = 0.5, label = "R=0.96")

ggplot(data = iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) + 
  geom_point(aes(shape = Species), size = 3) + 
  scale_shape_manual(values = c(16, 17, 18)) + 
  scale_color_manual(values = c("purple",
                                "black",
                                "orange"))

ggplot(iris) +
  aes(x = Petal.Length, y = Petal.Width) +                 # define space
  geom_point( aes(color = Species, shape = Species) ) +    # add points
  geom_smooth(method =lm) +                                # add trend line  
  annotate("text", x = 5, y = 0.5, label = "R=0.96") +     # annotate with text
  xlab("Petal length (cm)") +                              # x-axis labels
  ylab("Petal width (cm)") +                               # y-axis labels
  ggtitle( "Correlation between petal length and width")   # title

# Box plots
library(ggplot2)
ggplot(data = iris) +
  aes(x = Species, y = Sepal.Length, color = Species) +
  geom_boxplot()

ggplot(data = iris) +
  aes(x = Species, y = Sepal.Length, color = Species) +
  geom_boxplot() +
  geom_jitter(position = position_jitter(0.2))

ggplot(data = iris) +
  aes(x = Petal.Length, fill = Species) + 
  geom_density( alpha = 0.3)

ggplot(data = iris) +
  aes(x = Petal.Length, fill = Species) + 
  geom_density( alpha = 0.3) +
  facet_wrap(~ Species, nrow = 3) 
#  Facetting

ggplot(data = iris, aes(x = Sepal.Length, y = Sepal.Width)) + 
  geom_point(size = 3) + 
  geom_smooth(size = 1) + 
  facet_wrap(~ Species)

ggplot(data = iris, aes(x = Sepal.Length, y = Sepal.Width)) + 
  geom_point(size = 3) + 
  geom_smooth(size = 1, se = FALSE) + 
  facet_grid(rows = vars(Species))


