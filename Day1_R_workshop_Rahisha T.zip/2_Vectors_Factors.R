#vector basics
#Using vectors and factors

layers <- c('Parcels', 'Streets', 'Railroads', 'Streams', 'Buildings')
length(layers)


layers[3]

layers[3:5]


layers

layers[-4]

nonvector <- c(1, TRUE, "three")

nonvector

#combining vectors
layerIds <- c(1,2,3,4)
combinedVector = c(layers, layerIds)
combinedVector

#vector arithmetic

x <- c(10,20,30,40,50)
y <- c(100,200,300,400,500)

x + y
y - x
10 * x
20 * y

#vector functions/operators
length(x)
sum(x)
mean(y)
median(y)
max(y)
min(x)
summary(x)
print(sort(x))
?sort
################################################################

#factors

land.type <- factor(c("Residential", "Commercial", "Agri-cultural","Commercial", "Commercial", "Residential"))

table(land.type)

land.type

mons <- c("March", "April", "January", "November", "Janu-ary", 
         "September", "October", "September", "November", "August",
         "January", "November", "November", "February", "May", "August",
         "July", "December", "August", "August", "September", "November",
         "February", "April")

mons <- factor(mons)
class(mons)

table(mons)

mons
mons <- factor(mons, levels=c('January', 'February', 'March',
                             'April', 'May', 'June', 'July', 'August', 'September',
                             'October', 'November','December'), ordered=TRUE)
table(mons)

mons

################################################################


#Using lists

my.list <- list("Streets", 2000, "Parcels", 5000, TRUE, FALSE)

my.list[2]

my.list[[2]]
#list slicing
new.list <- my.list[c(1,2)]

new.list
new.list[[2]]

length(my.list)
is.list(my.list)
#Lists

y <- list(5, "John Doe", c(100, 7), mean) # a list with 4 components
y