#You can use R as a calculator

1 / 200 * 30

(59 + 73 + 2) / 3

sin(pi / 2)
#############################################
# Assigning values
(a <- 1+2)


#print(a)
x <- 3 * 4

y <- "hello world"

this_is_a_really_long_name <- 2.5

seq(1, 10)

y <- seq(1, 10, length.out = 5)
y

(y <- seq(1, 10, length.out = 5))# Print to screen

##############################################
#Creating variables and assigning data

x <- 10
y = 20
z = x + y
z
print(z)

################################################
myCollege = "IIITB"  #replace myCollege with yours

mycollege 

class(4) 

plot(rnorm(1000)) 

#Comments 

# This is a comment 

#Getting Documentation for Functions 

?length

ls()

rm(a) 
###############################################
x <- 2 

x 

2 * x 

2 -> x 

x <- "invisible" 

(y <- "visible") 

length("max") 

length(c("KSTA", "IIITB")) 

#function c() 

nchar("max") 

nchar("R is powerful") 

nchar(c("foo", "barz")) 
#############################################