#Iris data visualization
#install.packages(tidyverse)

library(tidyverse)

# iris=read.csv('../input/Iris.csv')

view(iris)


head(iris, n=5)

tail(iris, n=5)

table(iris$Species)

PL <- iris$Petal.Length
PW <- iris$Petal.Width

#Creating a Scatter Plot
plot(PW, PL)

# plot(iris$Petal.Length, iris$Petal.Width)


plot(PL, PW, pch = 2) # pch = 2 means the symbol is triangle

? plot

plot(PL, PW, pch = 8, col = "red") # change the symbol color to green

# Show the information of Species
(iris$Species)

# class(iris$Species)

class(iris$Species)

speciesID <- as.numeric(iris$Species)
speciesID

class(speciesID)

plot(PL, PW, pch = speciesID, col = "blue") 

# assign 3 colors red, green, and blue to 3 species *setosa*, *versicolor*, 
# and *virginica* respectively 
plot(PL, PW, pch = speciesID, col = rainbow(3)[iris$Species])

class(iris$Sepal.Length)
class(as.factor(iris$Sepal.Length))
# variables contained in the dataset *iris*
colnames(iris)

plot(PL, PW,                               # x and y
     pch = speciesID,                      # symbol type
     col = rainbow(3)[speciesID],          # color
     xlab = "Petal length (cm)",           # x label
     ylab = "Petal width (cm)",            # y label
     main = "Petal width vs. length")      # main title
abline( lm(PW ~ PL) ) # the order is reversed as we need y ~ x.

PCC <- cor(PW, PL)  # Pearson's correlation coefficient
PCC <- round(PCC, 2) # round to the 2nd place after decimal point.
PCC

PL <- iris$Petal.Length
PW <- iris$Petal.Width
plot(PL, PW,  
     pch = speciesID, # assign different symbols to different species 
     col = rainbow(3)[speciesID], # assign different colors to different species
     xlab = "Petal length (cm)", # label x-axis
     ylab = "Petal width (cm)", # label y-axis
     main = "Petal width vs. length") # add a title to the plot
abline( lm(PW ~ PL))  # add a regression line to the plot
text(5, 0.5, paste("R=", PCC)) # add text annotation. 
# PCC is the Pearson's correlation coefficient calculated above
legend("topleft", # specify the location of the legend
       levels(iris$Species), # specify the levels of species
       pch = 1:3, # specify three symbols used for the three species
       col = rainbow(3)) # specify three colors for the three species

# Scatter plot matrix

ma <- as.matrix(iris[, 1:4])  # convert to matrix
colMeans(ma)  # column means for matrix
colSums(ma)
pairs(ma) 
pairs(ma, col = rainbow(3)[iris$Species])  # set colors by species

# Box plot
boxplot(PL) # boxplot of Petal Length.
boxplot(iris[, 1:4]) # boxplots of four columns for iris.

plot(PL) # Run scatter plot
hist(PL) # histogram
lag.plot(PL) # lag plot
qqnorm(PL) # Q-Q plot for normal distribution
qqline(PL) # add the regression line


