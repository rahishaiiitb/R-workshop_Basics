#working with matrices
m1 <- rbind(c(3, 4, 5), c(10, 13, 15)) # combine vectors by row
m1

n1 <- cbind(c(3, 4, 5), c(10, 13, 15), c(3, 2, 1)) # combine vectors by column
n1

class(m1)
class(n1)
#matrx1 <- matrix(c(2,4,3,1,5,7), nrow=2, ncol=3)
#matrx1
matrx <- matrix(c(2,4,3,1,5,7), nrow=2, ncol=3, byrow=TRUE)
matrx


colnames(matrx) <- c("POP2000", "POP2005", "POP2010")


matrx[2,3] # row col

matrx[2,]
matrx[,3]
matrx[,c(1,3)]
matrx[, "POP2005"]
colSums(matrx)
colMeans(matrx)
#######################################################################
#working with data frames
data()
data("iris")

iris

iris$Petal.Width


iris[50,2]

iris[50,]

# Create the data frame. 

x <- c("A", "B", "C", "D")
y <- c(41, 32, 13, 89)
z <- c("TRUE", "FALSE", "FALSE", "TRUE")
df1 <- data.frame(x, y, z)
df1

dim(df1)

nrow(df1)

ncol(df1)

str(df1)



BMI <- data.frame(gender = c("Male", "Male", "Female"),
                  
                  height = c(152, 171.5, 165), 
                  
                  weight = c(81,93, 78), 
                  
                  Age = c(42,38,26)  ) 

print(BMI)
#########################################################################
# create an array

vec1 <- c(1,2,4)    
vec2 <- c(15,17,27,3,10,11)
output <- array(c(vec1,vec2),dim = c(3,3,2))
output
x[1,3,2]
x = array(1:24,c(3,4,2))
print(x)