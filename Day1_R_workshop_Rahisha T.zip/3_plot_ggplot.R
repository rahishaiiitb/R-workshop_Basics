# Exploring Data

# Creating a Scatter Plot

plot(mtcars$wt, mtcars$mpg)
head(mtcars)

library(ggplot2)

ggplot(mtcars, aes(x = wt, y = mpg)) +
  geom_point()

ggplot(data = NULL, aes(x = mtcars$wt, y = mtcars$mpg)) +
  geom_point()
############################################

#Creating a Line Graph

head(pressure)
plot(pressure$temperature, pressure$pressure, type = "l")


points(pressure$temperature, pressure$pressure)

lines(pressure$temperature, pressure$pressure/2, col = "red")
points(pressure$temperature, pressure$pressure/2, col = "red")


library(ggplot2)
ggplot(pressure, aes(x = temperature, y = pressure)) +
  geom_line()
ggplot(pressure, aes(x = temperature, y = pressure)) +
  geom_line() +
  geom_point()

##########################################################
# Creating a Bar Graph

#Biochemical Oxygen Demand
?BOD
BOD

barplot(BOD$demand, names.arg = BOD$Time)


library(ggplot2)

# Bar graph of values. This uses the BOD data frame, with the
# "Time" column for x values and the "demand" column for y values.
ggplot(BOD, aes(x = Time, y = demand)) +
  geom_col()

# Convert the x variable to a factor, so that it is treated as discrete
ggplot(BOD, aes(x = factor(Time), y = demand)) +
  geom_col()
################################################################

# Creating a Histogram

hist(mtcars$mpg)

# Specify approximate number of bins with breaks
hist(mtcars$mpg, breaks = 10)


library(ggplot2)
ggplot(mtcars, aes(x = mpg)) +
  geom_histogram()
#> `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.

# With wider bins
ggplot(mtcars, aes(x = mpg)) +
  geom_histogram(binwidth = 4)

#####################################################################
# Creating a Box Plot
ToothGrowth

# Formula syntax
boxplot(len ~ supp, data = ToothGrowth)

# Put interaction of two variables on x-axis
boxplot(len ~ supp + dose, data = ToothGrowth)

library(ggplot2)
ggplot(ToothGrowth, aes(x = supp, y = len)) +
  geom_boxplot()

ggplot(ToothGrowth, aes(x = interaction(supp, dose), y = len)) +
  geom_boxplot()


